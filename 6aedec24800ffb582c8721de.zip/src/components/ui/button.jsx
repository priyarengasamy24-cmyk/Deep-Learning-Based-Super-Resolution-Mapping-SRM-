import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority";

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "gsx-btn-primary rounded-xl font-semibold hover:-translate-y-0.5 active:translate-y-0 active:brightness-95",
        destructive:
          "rounded-xl bg-destructive/90 text-destructive-foreground shadow-sm hover:bg-destructive",
        outline:
          "rounded-xl border border-gsx-teal/25 bg-white/[0.03] text-gsx-ink shadow-sm backdrop-blur-md hover:border-gsx-teal/60 hover:bg-gsx-teal/[0.08] hover:text-gsx-ink",
        secondary:
          "rounded-xl border border-gsx-line bg-gsx-card text-gsx-ink shadow-sm backdrop-blur-md hover:bg-gsx-terrain/80",
        ghost: "rounded-xl hover:bg-white/[0.06] hover:text-gsx-ink",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"
  return (
    (<Comp
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      {...props} />)
  );
})
Button.displayName = "Button"

export { Button, buttonVariants }