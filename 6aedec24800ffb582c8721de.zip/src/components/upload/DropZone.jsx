import { useRef, useState } from "react";
import { FileUp, UploadCloud } from "lucide-react";

export default function DropZone({ onFile, disabled }) {
  const inputRef = useRef(null);
  const [over, setOver] = useState(false);

  const pick = (files) => {
    const file = files?.[0];
    if (file) onFile(file);
  };

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        if (!disabled) pick(e.dataTransfer.files);
      }}
      className={[
        "group relative flex flex-col items-center justify-center overflow-hidden rounded-panellg border border-dashed px-6 py-12 text-center transition-all duration-300",
        over
          ? "border-gsx-teal bg-gsx-teal/[0.09] shadow-[0_0_60px_-20px_rgba(0,229,255,0.75),inset_0_0_0_1px_rgba(0,229,255,0.35)]"
          : "border-gsx-teal/25 bg-gsx-card hover:border-gsx-teal/50",
        disabled ? "opacity-60" : "",
      ].join(" ")}
    >
      <span aria-hidden="true" className="gsx-scanline" />
      <span aria-hidden="true" className="pointer-events-none absolute inset-0 gsx-grid-bg opacity-[0.35]" />

      <span className="relative grid h-12 w-12 animate-float-slow place-items-center rounded-xl border border-gsx-teal/30 bg-gradient-to-br from-gsx-teal/25 to-gsx-violet/20 shadow-[0_0_26px_-8px_rgba(0,229,255,0.9)]">
        <UploadCloud className="h-5 w-5 text-gsx-teal" strokeWidth={1.7} />
      </span>
      <p className="relative mt-4 font-heading text-[15px] font-semibold text-gsx-ink">
        Drag and drop your GeoTIFF here
      </p>
      <p className="relative mt-1.5 max-w-sm text-[12px] leading-relaxed text-gsx-muted">
        Accepted formats: .tif and .tiff. Files are uploaded to private storage (stored privately) and only readable
        through signed links.
      </p>
      <button
        type="button"
        disabled={disabled}
        onClick={() => inputRef.current?.click()}
        className="gsx-btn-primary relative mt-5 inline-flex items-center gap-2 rounded-xl px-4 py-2 text-[12px] font-semibold transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed"
      >
        <FileUp className="h-3.5 w-3.5" /> Browse files
      </button>
      <input
        ref={inputRef}
        type="file"
        accept=".tif,.tiff,image/tiff"
        className="hidden"
        onChange={(e) => {
          pick(e.target.files);
          e.target.value = "";
        }}
      />
    </div>
  );
}