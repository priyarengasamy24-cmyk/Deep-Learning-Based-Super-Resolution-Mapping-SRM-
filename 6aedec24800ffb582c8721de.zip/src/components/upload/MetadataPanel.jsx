import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { formatBytes } from "@/lib/format";

function Row({ label, value, mono }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-gsx-line/70 py-2 last:border-0">
      <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-gsx-muted">{label}</span>
      <span className={`text-right text-[12px] text-gsx-ink ${mono ? "font-mono text-[11px]" : ""}`}>
        {value === null || value === undefined || value === "" ? <em className="text-gsx-muted">Not available</em> : value}
      </span>
    </div>
  );
}

const LEVEL = {
  compatible: { icon: CheckCircle2, cls: "border-gsx-success/40 bg-gsx-success/[0.07] text-gsx-success" },
  partial: { icon: AlertTriangle, cls: "border-gsx-warn/40 bg-gsx-warn/[0.07] text-gsx-warn" },
  incompatible: { icon: XCircle, cls: "border-gsx-danger/40 bg-gsx-danger/[0.07] text-gsx-danger" },
};

export default function MetadataPanel({ meta, fileSize }) {
  if (!meta) return null;

  if (!meta.ok) {
    return (
      <div className="border border-gsx-warn/40 bg-gsx-warn/[0.07] p-4">
        <p className="flex items-center gap-2 text-[12px] font-bold text-gsx-warn">
          <AlertTriangle className="h-4 w-4" /> Metadata could not be extracted
        </p>
        <p className="mt-1.5 text-[12px] leading-relaxed text-gsx-warn/90">{meta.reason}</p>
        <p className="mt-2 text-[11.5px] leading-relaxed text-gsx-muted">
          The file is still stored and linked to the record. Nothing is invented to fill the missing fields.
        </p>
      </div>
    );
  }

  const level = LEVEL[meta.compatibility.level] || LEVEL.partial;
  const Icon = level.icon;
  const bounds = meta.bounds
    ? `W ${meta.bounds.west.toFixed(5)} · S ${meta.bounds.south.toFixed(5)} · E ${meta.bounds.east.toFixed(5)} · N ${meta.bounds.north.toFixed(5)}`
    : null;

  return (
    <div className="space-y-3">
      <div className={`flex items-start gap-2.5 border p-3 ${level.cls}`}>
        <Icon className="mt-0.5 h-4 w-4 shrink-0" />
        <div>
          <p className="text-[11.5px] font-bold uppercase tracking-[0.1em]">{meta.compatibility.label}</p>
          <ul className="mt-1 space-y-0.5">
            {meta.compatibility.reasons.map((r) => (
              <li key={r} className="text-[11.5px] leading-relaxed opacity-90">
                {r}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="gsx-glass px-4 py-2">
        <Row label="Satellite" value={meta.satelliteName} />
        <Row label="Acquisition date" value={meta.acquisitionDate} />
        <Row label="CRS" value={meta.crs} mono />
        <Row label="Spatial resolution" value={meta.resolutionM ? `${meta.resolutionM} m` : null} />
        <Row label="Image dimensions" value={meta.width && meta.height ? `${meta.width} × ${meta.height} px` : null} mono />
        <Row label="Geographic bounds" value={bounds} mono />
        <Row label="Number of bands" value={meta.bands} />
        <Row label="Bit depth" value={meta.bitsPerSample ? `${meta.bitsPerSample} bit` : null} />
        <Row label="Compression" value={meta.compression} />
        <Row label="File size" value={fileSize ? formatBytes(fileSize) : null} />
        <Row label="Byte order" value={meta.byteOrder} mono />
      </div>

      <p className="text-[11px] leading-relaxed text-gsx-muted">{meta.resolutionNote}</p>

      {meta.warnings.length > 0 && (
        <ul className="space-y-1 border-l-2 border-gsx-warn/60 pl-3">
          {meta.warnings.map((w) => (
            <li key={w} className="text-[11px] leading-relaxed text-gsx-muted">
              {w}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}