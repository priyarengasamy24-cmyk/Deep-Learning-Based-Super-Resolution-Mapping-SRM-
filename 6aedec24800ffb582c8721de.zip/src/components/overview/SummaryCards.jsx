import { CheckCircle2, Images, Ruler, Timer } from "lucide-react";
import { formatDuration } from "@/lib/format";

const CARDS = [
  { key: "images", label: "Total images uploaded", icon: Images, hint: "GeoTIFF scenes in your workspace" },
  { key: "completed", label: "Completed processing tasks", icon: CheckCircle2, hint: "Jobs that reached output stage" },
  { key: "avg", label: "Average processing time", icon: Timer, hint: "Across completed jobs" },
  { key: "target", label: "Target resolution", icon: Ruler, hint: "4× finer than input", accent: true },
];

export default function SummaryCards({ stats }) {
  const values = {
    images: stats.images ?? 0,
    completed: stats.completed ?? 0,
    avg: stats.avgSeconds === null || stats.avgSeconds === undefined ? "—" : formatDuration(stats.avgSeconds),
    target: "2.5 m",
  };

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {CARDS.map((c, i) => {
        const Icon = c.icon;
        return (
          <div
            key={c.key}
            className={`${c.accent ? "gsx-glass-accent" : "gsx-glass"} gsx-lift animate-rise p-5`}
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <div className="flex items-start justify-between gap-3">
              <p className="text-[10.5px] font-semibold uppercase tracking-[0.13em] text-gsx-muted">{c.label}</p>
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-gsx-teal/25 bg-gradient-to-br from-gsx-teal/20 to-gsx-violet/15">
                <Icon className="h-4 w-4 text-gsx-teal" strokeWidth={1.9} />
              </span>
            </div>
            <p className="mt-4 font-heading text-[27px] font-bold leading-none text-gsx-ink [text-shadow:0_0_24px_rgba(0,229,255,0.25)]">
              {values[c.key]}
            </p>
            <p className="mt-2 text-[11px] text-gsx-muted">{c.hint}</p>
          </div>
        );
      })}
    </div>
  );
}