import { Download, FileText, ImageOff, Layers3 } from "lucide-react";
import { formatDate } from "@/lib/format";
import { StatusBadge } from "@/components/kit/StatusBadge";

function Row({ label, value, mono }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-gsx-line/70 py-2 last:border-0">
      <span className="text-[10.5px] font-semibold uppercase tracking-[0.08em] text-gsx-muted">{label}</span>
      <span className={`text-right text-[11.5px] text-gsx-ink ${mono ? "font-mono text-[11px]" : ""}`}>
        {value || <em className="text-gsx-muted">Not available</em>}
      </span>
    </div>
  );
}

export default function GeospatialPanel({ image, job, metrics, onExport, onDownloadOutput, outputBusy }) {
  return (
    <div className="space-y-4">
      <section className="gsx-glass">
        <header className="flex items-center justify-between border-b border-gsx-line px-4 py-3">
          <h2 className="text-[11px] font-bold uppercase tracking-[0.13em] text-gsx-ink">Geographic information</h2>
          <Layers3 className="h-3.5 w-3.5 text-gsx-teal" />
        </header>
        <div className="px-4 py-2">
          <Row label="Satellite" value={image?.satellite_name} />
          <Row label="Acquisition date" value={image?.acquisition_date} />
          <Row label="CRS" value={image?.crs} mono />
          <Row label="Bounds" value={image?.bounds_label} mono />
          <Row label="Dimensions" value={image?.dimensions} mono />
          <Row label="Spectral bands" value={image?.band_count ? `${image.band_count} bands` : null} />
          <Row label="Job status" value={<StatusBadge status={job?.status} />} />
        </div>
      </section>

      <section className="gsx-glass">
        <header className="border-b border-gsx-line px-4 py-3">
          <h2 className="text-[11px] font-bold uppercase tracking-[0.13em] text-gsx-ink">Resolution information</h2>
        </header>
        <div className="px-4 py-2">
          <Row label="Input resolution" value={`${job?.input_resolution || 10} m`} />
          <Row label="Target resolution" value={`${job?.target_resolution || 2.5} m`} />
          <Row label="Scale factor" value={`${job?.scale_factor || 4}×`} />
          <Row label="Selected bands" value={(job?.bands || []).join(" · ")} mono />
          <Row label="Model" value={job?.model_name} />
          <Row label="Completed" value={job?.completed_at ? formatDate(job.completed_at, true) : null} />
        </div>
        <div className="border-t border-gsx-line p-4">
          <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-gsx-muted">Output raster</p>
          {job?.output_available && job?.output_file_uri ? (
            <button
              type="button"
              onClick={onDownloadOutput}
              disabled={outputBusy}
              className="mt-2 inline-flex items-center gap-2 border border-gsx-teal bg-gsx-teal px-4 py-2 text-[12px] font-semibold text-gsx-navy hover:bg-transparent hover:text-gsx-forest disabled:opacity-60"
            >
              <Download className="h-3.5 w-3.5" /> Download GeoTIFF output
            </button>
          ) : (
            <p className="mt-1.5 flex gap-2 text-[11.5px] leading-relaxed text-gsx-muted">
              <ImageOff className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              No GeoTIFF was produced. Demo mode does not run a model, so no output raster exists to download.
            </p>
          )}

          <button
            type="button"
            onClick={onExport}
            className="mt-3 inline-flex items-center gap-2 border border-gsx-ink/25 px-4 py-2 text-[12px] font-semibold text-gsx-ink hover:border-gsx-ink"
          >
            <FileText className="h-3.5 w-3.5" /> Export processing report
          </button>
          {metrics && (
            <p className="mt-2 text-[10.5px] leading-relaxed text-gsx-muted">
              Report accuracy values: {metrics.source === "measured" ? "measured" : "PPT reference values"}.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}

export { StatusBadge };