import { useRef, useState } from "react";
import { Image } from "@/components/ui/image";
import { IMAGES } from "@/lib/site-data";

/**
 * Comparison stage for the results explorer. The demo scene is one illustrative
 * satellite image; the "10 m" pane is the same scene degraded (blur + reduced
 * contrast) to show what coarse sampling does. No model output is displayed.
 */
export default function CompareStage({ zoom = 1, showOriginal, showOutput, mode = "slider" }) {
  const [pos, setPos] = useState(50);
  const dragging = useRef(false);
  const box = useRef(null);

  const move = (clientX) => {
    const rect = box.current?.getBoundingClientRect();
    if (!rect) return;
    setPos(Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100)));
  };

  const Layer = ({ degraded }) => (
    <div
      className="absolute inset-0"
      style={degraded ? { filter: "blur(2.6px) contrast(0.9) saturate(0.9)", transform: "scale(1.02)" } : undefined}
    >
      <Image src={IMAGES.demoScene} alt="Illustrative satellite scene" className="h-full w-full object-cover" />
    </div>
  );

  if (mode === "side") {
    return (
      <div className="grid gap-px bg-gsx-line sm:grid-cols-2">
        <div className="relative h-[260px] overflow-hidden bg-gsx-navy sm:h-[340px]">
          {showOriginal && <Layer degraded />}
          <span className="absolute left-3 top-3 border border-white/25 bg-gsx-navy/85 px-2 py-0.5 font-mono text-[9.5px] font-bold uppercase tracking-[0.1em] text-white">
            Simulated 10 m
          </span>
        </div>
        <div className="relative h-[260px] overflow-hidden bg-gsx-navy sm:h-[340px]">
          {showOutput && <Layer />}
          <span aria-hidden="true" className="gsx-scanline opacity-60" />
          <span className="absolute left-3 top-3 border border-gsx-teal/50 bg-gsx-navy/85 px-2 py-0.5 font-mono text-[9.5px] font-bold uppercase tracking-[0.1em] text-gsx-teal">
            Reference 2.5 m detail
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={box}
      onPointerDown={(e) => {
        dragging.current = true;
        e.currentTarget.setPointerCapture(e.pointerId);
        move(e.clientX);
      }}
      onPointerMove={(e) => dragging.current && move(e.clientX)}
      onPointerUp={() => {
        dragging.current = false;
      }}
      onPointerCancel={() => {
        dragging.current = false;
      }}
      className="relative h-[300px] cursor-col-resize touch-none overflow-hidden bg-gsx-navy select-none sm:h-[400px]"
    >
      <span aria-hidden="true" className="gsx-scanline z-10 opacity-70" />
      {showOutput && (
        <div
          className="absolute inset-0 transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          <Layer />
        </div>
      )}
      {showOriginal && (
        <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
          <div
            className="absolute inset-0 transition-transform duration-200"
            style={{ transform: `scale(${zoom})` }}
          >
            <Layer degraded />
          </div>
        </div>
      )}

      {showOriginal && showOutput && (
        <>
          <div className="pointer-events-none absolute inset-y-0 w-px bg-gsx-teal" style={{ left: `${pos}%` }} />
          <div
            className="pointer-events-none absolute top-1/2 grid h-8 w-8 -translate-x-1/2 -translate-y-1/2 place-items-center border border-gsx-teal bg-gsx-navy"
            style={{ left: `${pos}%` }}
          >
            <span className="font-mono text-[10px] text-gsx-teal">↔</span>
          </div>
        </>
      )}

      {showOriginal && (
        <span className="pointer-events-none absolute left-3 top-3 border border-white/25 bg-gsx-navy/85 px-2 py-0.5 font-mono text-[9.5px] font-bold uppercase tracking-[0.1em] text-white">
          Simulated 10 m input
        </span>
      )}
      {showOutput && (
        <span className="pointer-events-none absolute right-3 top-3 border border-gsx-teal/50 bg-gsx-navy/85 px-2 py-0.5 font-mono text-[9.5px] font-bold uppercase tracking-[0.1em] text-gsx-teal">
          2.5 m reference detail
        </span>
      )}
      {(!showOriginal || !showOutput) && (
        <span className="pointer-events-none absolute bottom-3 left-3 border border-white/20 bg-gsx-navy/85 px-2 py-0.5 text-[10px] text-white/70">
          {!showOriginal && !showOutput ? "Both layers hidden" : !showOriginal ? "10 m layer hidden" : "SR layer hidden"}
        </span>
      )}
    </div>
  );
}