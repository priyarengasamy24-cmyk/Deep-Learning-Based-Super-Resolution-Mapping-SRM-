import { Check, Loader2 } from "lucide-react";
import { PIPELINE_STAGES } from "@/lib/site-data";

export default function ArchitectureFlow({ activeIndex = -1, completed = false }) {
  return (
    <ol className="relative">
      {PIPELINE_STAGES.map((stage, i) => {
        const done = completed || i < activeIndex;
        const active = !completed && i === activeIndex;
        return (
          <li key={stage.key} className="flex gap-3">
            <div className="flex flex-col items-center">
              <span
                className={[
                  "grid h-6 w-6 shrink-0 place-items-center border text-[9.5px] font-bold transition-colors",
                  done
                    ? "border-gsx-teal bg-gsx-teal text-gsx-navy"
                    : active
                      ? "border-gsx-teal bg-gsx-teal/15 text-gsx-teal"
                      : "border-white/15 text-white/35",
                ].join(" ")}
              >
                {done ? <Check className="h-3 w-3" strokeWidth={3.5} /> : String(i + 1).padStart(2, "0")}
              </span>
              {i < PIPELINE_STAGES.length - 1 && (
                <span className={`my-1 w-px flex-1 ${done ? "bg-gsx-teal/40" : "bg-white/10"}`} />
              )}
            </div>
            <div className={`pb-3.5 transition-opacity ${active || done ? "opacity-100" : "opacity-55"}`}>
              <p
                className={`text-[12.5px] font-semibold leading-tight ${active ? "text-gsx-teal" : "text-white"}`}
              >
                {stage.title}
                {active && <Loader2 className="ml-1.5 inline h-3 w-3 animate-spin text-gsx-teal" />}
              </p>
              <p className="mt-0.5 text-[10.5px] text-white/40">{stage.meta}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}