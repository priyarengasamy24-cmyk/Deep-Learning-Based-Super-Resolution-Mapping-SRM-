import { Link } from "@tanstack/react-router";
import { Satellite } from "lucide-react";

const NAV = [
  { to: "/overview", label: "Overview" },
  { to: "/upload", label: "Image Upload" },
  { to: "/processing", label: "Processing" },
  { to: "/results", label: "Results" },
  { to: "/accuracy", label: "Accuracy" },
  { to: "/history", label: "History" },
  { to: "/documentation", label: "Documentation" },
];

export default function SiteFooter() {
  return (
    <footer className="bg-gsx-sidebar">
      <div className="mx-auto max-w-[1240px] px-5 py-14 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center border border-gsx-teal/40 bg-gsx-teal/10">
                <Satellite className="h-4 w-4 text-gsx-teal" strokeWidth={1.75} />
              </span>
              <div>
                <p className="font-heading text-[17px] font-bold text-white">
                  GeoSR<span className="text-gsx-teal">-X</span>
                </p>
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/35">
                  Geospatial Super Resolution Explorer
                </p>
              </div>
            </div>
            <p className="mt-5 max-w-sm text-[13px] leading-relaxed text-white/45">
              AI-Powered Satellite Super Resolution Mapping — 10 m Sentinel-2 imagery reconstructed to 2.5 m with a
              hybrid CNN and Swin Transformer architecture.
            </p>
          </div>

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Platform</p>
            <ul className="mt-4 grid gap-2.5">
              {NAV.map((n) => (
                <li key={n.to}>
                  <Link
                    to={n.to}
                    className="text-[13px] text-white/55 transition-colors hover:text-gsx-teal"
                  >
                    {n.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Programme</p>
            <dl className="mt-4 space-y-2.5 text-[13px]">
              <div>
                <dt className="text-white/35">Event</dt>
                <dd className="text-white/75">Smart India Hackathon 2026</dd>
              </div>
              <div>
                <dt className="text-white/35">Problem Statement ID</dt>
                <dd className="font-mono text-gsx-teal">SIH26142</dd>
              </div>
              <div>
                <dt className="text-white/35">Theme</dt>
                <dd className="text-white/75">Space Technology</dd>
              </div>
              <div>
                <dt className="text-white/35">Team</dt>
                <dd className="font-semibold text-white">TRUSTIANS</dd>
              </div>
            </dl>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-white/10 pt-6 text-[11.5px] text-white/35 sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 GeoSR-X · Team TRUSTIANS. All rights reserved.</p>
          <p>Built for research and demonstration use. Model inference requires a connected backend.</p>
        </div>
      </div>
    </footer>
  );
}