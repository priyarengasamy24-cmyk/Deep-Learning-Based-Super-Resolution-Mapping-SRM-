const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { CheckCircle2, FileText, Loader2, ShieldCheck, X } from "lucide-react";

import { inspectGeoTiff } from "@/lib/inspect-geotiff";
import { formatBytes } from "@/lib/format";
import PageHeader from "@/components/kit/PageHeader";
import DropZone from "@/components/upload/DropZone";
import MetadataPanel from "@/components/upload/MetadataPanel";

const ACCEPTED = [".tif", ".tiff"];
const MAX_BYTES = 500 * 1024 * 1024;

const PHASES = {
  uploading: "Uploading file to private storage…",
  inspecting: "Reading TIFF header and GeoTIFF tags…",
  saving: "Saving image record…",
};

export const Route = createFileRoute("/_authed/upload")({ component: UploadPage });

function UploadPage() {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [phase, setPhase] = useState("idle");
  const [meta, setMeta] = useState(null);
  const [error, setError] = useState(null);
  const [saved, setSaved] = useState(null);

  const busy = phase !== "idle";

  const selectFile = (picked) => {
    setError(null);
    setMeta(null);
    const ext = picked.name.slice(picked.name.lastIndexOf(".")).toLowerCase();
    if (!ACCEPTED.includes(ext)) {
      setError("Unsupported format. GeoSR-X accepts GeoTIFF files with a .tif or .tiff extension.");
      return;
    }
    if (picked.size > MAX_BYTES) {
      setError(`File is ${formatBytes(picked.size)}. The maximum accepted size is ${formatBytes(MAX_BYTES)}.`);
      return;
    }
    setFile(picked);
  };

  const runUpload = async () => {
    if (!file) return;
    setError(null);
    try {
      setPhase("uploading");
      const { file_uri } = await db.integrations.Core.UploadPrivateFile({ file });

      setPhase("inspecting");
      const { signed_url } = await db.integrations.Core.CreateFileSignedUrl({ file_uri, expires_in: 300 });
      const result = await inspectGeoTiff({ data: { signedUrl: signed_url } });
      setMeta(result);

      if (result.ok && result.compatibility.level === "incompatible") {
        setPhase("idle");
        setError(result.compatibility.reasons[0] || "This file is not compatible with Sentinel-2 multispectral processing.");
        return;
      }

      setPhase("saving");
      const bounds = result.ok ? result.bounds : null;
      const record = await db.entities.SatelliteImage.create({
        file_name: file.name,
        file_uri,
        file_size: file.size,
        satellite_name: result.ok ? result.satelliteName : null,
        acquisition_date: result.ok ? result.acquisitionDate : null,
        resolution_m: result.ok ? result.resolutionM : null,
        resolution_note: result.ok ? result.resolutionNote : result.reason,
        crs: result.ok ? result.crs : null,
        bounds_west: bounds?.west ?? null,
        bounds_south: bounds?.south ?? null,
        bounds_east: bounds?.east ?? null,
        bounds_north: bounds?.north ?? null,
        bounds_label: bounds
          ? `W ${bounds.west.toFixed(5)} · S ${bounds.south.toFixed(5)} · E ${bounds.east.toFixed(5)} · N ${bounds.north.toFixed(5)}`
          : null,
        band_count: result.ok ? result.bands : null,
        width: result.ok ? result.width : null,
        height: result.ok ? result.height : null,
        dimensions: result.ok && result.width ? `${result.width} × ${result.height} px` : null,
        compression: result.ok ? result.compression : null,
        metadata_source: result.ok ? "extracted" : "not_available",
        metadata_warnings: result.ok ? result.warnings : [result.reason],
        processing_status: "uploaded",
      });

      setSaved(record);
      setPhase("idle");
      toast.success("Imagery uploaded and registered.");
    } catch (err) {
      setPhase("idle");
      setError(err?.message || "The upload did not complete. Please try again.");
      toast.error("Upload failed.");
    }
  };

  const reset = () => {
    setFile(null);
    setMeta(null);
    setSaved(null);
    setError(null);
  };

  return (
    <>
      <PageHeader
        eyebrow="Satellite image upload"
        title="Ingest Sentinel-2 GeoTIFF imagery"
        description="Upload a multispectral GeoTIFF scene. Header metadata is read from the file itself — never inferred."
      />

      <div className="grid gap-4 lg:grid-cols-[1.25fr_1fr]">
        <div className="space-y-4">
          {!saved && <DropZone onFile={selectFile} disabled={busy} />}

          {file && !saved && (
            <div className="flex items-center justify-between gap-3 gsx-glass px-4 py-3">
              <div className="flex min-w-0 items-center gap-3">
                <FileText className="h-4 w-4 shrink-0 text-gsx-teal" />
                <div className="min-w-0">
                  <p className="truncate text-[12.5px] font-semibold text-gsx-ink">{file.name}</p>
                  <p className="text-[11px] text-gsx-muted">{formatBytes(file.size)}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={reset}
                disabled={busy}
                className="grid h-7 w-7 shrink-0 place-items-center border border-gsx-line text-gsx-muted transition-colors hover:border-gsx-danger hover:text-gsx-danger disabled:opacity-40"
                aria-label="Remove file"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {busy && (
            <div className="gsx-glass p-4">
              <div className="flex items-center gap-2 text-[12px] font-medium text-gsx-ink">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-gsx-teal" />
                {PHASES[phase]}
              </div>
              <div className="mt-3 h-1 w-full overflow-hidden bg-gsx-terrain">
                <div className="h-full w-1/3 animate-[scan_1.4s_linear_infinite] bg-gsx-teal" />
              </div>
            </div>
          )}

          {error && (
            <div className="border border-gsx-danger/40 bg-gsx-danger/[0.06] px-4 py-3 text-[12px] leading-relaxed text-gsx-danger">
              {error}
            </div>
          )}

          {file && !saved && (
            <button
              type="button"
              onClick={runUpload}
              disabled={busy}
              className="inline-flex items-center gap-2 border border-gsx-teal bg-gsx-teal px-5 py-2.5 text-[12.5px] font-semibold text-gsx-navy transition-colors hover:bg-transparent hover:text-gsx-forest disabled:cursor-not-allowed disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldCheck className="h-3.5 w-3.5" />}
              {busy ? "Working…" : "Upload & inspect metadata"}
            </button>
          )}

          {saved && (
            <div className="border border-gsx-success/40 bg-gsx-success/[0.06] p-4">
              <p className="flex items-center gap-2 text-[12.5px] font-bold text-gsx-success">
                <CheckCircle2 className="h-4 w-4" /> Upload complete
              </p>
              <p className="mt-1.5 text-[12px] leading-relaxed text-gsx-ink/75">
                {saved.file_name} is registered. Continue to spectral band selection to choose the four input bands.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => navigate({ to: "/bands", search: { imageId: saved.id } })}
                  className="border border-gsx-teal bg-gsx-teal px-4 py-2 text-[12px] font-semibold text-gsx-navy hover:bg-transparent hover:text-gsx-forest"
                >
                  Continue to band selection
                </button>
                <button
                  type="button"
                  onClick={reset}
                  className="border border-gsx-ink/25 px-4 py-2 text-[12px] font-semibold text-gsx-ink hover:border-gsx-ink"
                >
                  Upload another
                </button>
              </div>
            </div>
          )}
        </div>

        <div>
          {meta ? (
            <MetadataPanel meta={meta} fileSize={file?.size} />
          ) : (
            <div className="gsx-glass p-5">
              <p className="text-[12px] font-bold uppercase tracking-[0.13em] text-gsx-ink">Metadata extraction</p>
              <p className="mt-2 text-[12px] leading-relaxed text-gsx-muted">
                After upload, the GeoTIFF header is parsed on the server for width, height, band count, pixel scale,
                tiepoints, CRS geokeys and any embedded GDAL metadata.
              </p>
              <ul className="mt-4 space-y-2 border-t border-gsx-line pt-3">
                {[
                  "Satellite and acquisition date — only when present in the file",
                  "CRS resolved from EPSG geokeys",
                  "Bounds derived from tiepoints or an affine transform",
                  "Spectral compatibility checked against four required bands",
                ].map((t) => (
                  <li key={t} className="flex gap-2 text-[11.5px] leading-relaxed text-gsx-muted">
                    <span className="mt-1.5 h-1 w-1 shrink-0 bg-gsx-teal" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </>
  );
}