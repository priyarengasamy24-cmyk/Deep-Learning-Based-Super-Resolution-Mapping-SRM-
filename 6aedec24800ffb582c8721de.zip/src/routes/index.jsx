import { createFileRoute } from "@tanstack/react-router";
import LandingHeader from "@/components/landing/LandingHeader";
import Hero from "@/components/landing/Hero";
import AboutProblem from "@/components/landing/AboutProblem";
import SolutionSection from "@/components/landing/SolutionSection";
import TechStackSection from "@/components/landing/TechStackSection";
import ApplicationsSection from "@/components/landing/ApplicationsSection";
import ReferencesSection from "@/components/landing/ReferencesSection";
import SiteFooter from "@/components/SiteFooter";

export const Route = createFileRoute("/")({
  component: LandingPage,
  head: () => ({
    meta: [
      { title: "GeoSR-X — Satellite Image Super Resolution Mapping" },
      {
        name: "description",
        content:
          "GeoSR-X transforms 10 m Sentinel-2 imagery into 2.5 m high-resolution intelligence using a Hybrid CNN and Swin Transformer architecture.",
      },
    ],
  }),
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-gsx-card">
      <LandingHeader />
      <main>
        <Hero />
        <AboutProblem />
        <SolutionSection />
        <TechStackSection />
        <ApplicationsSection />
        <ReferencesSection />
      </main>
      <SiteFooter />
    </div>
  );
}